
plot_time = all_states(1,:);
plot_travel = all_states(2,:);
figure(3)
plot(plot_time, plot_travel);